package com.cg.plp.bean;

public class BookTransactionBean 
{
	private String transactionId;
	private String userId;
	private String bookId;
	
	public String getTransactionId() 
	{
		return transactionId;
	}
	public void setTransactionId(String transactionId) 
	{
		this.transactionId = transactionId;
	}
	
	public String getUserId()
	{
		return userId;
	}
	public void setUserId(String userId)
	{
		this.userId = userId;
	}
	
	public String getBookId()
	{
		return bookId;
	}
	public void setBookId(String bookId) 
	{
		this.bookId = bookId;
	}
}
