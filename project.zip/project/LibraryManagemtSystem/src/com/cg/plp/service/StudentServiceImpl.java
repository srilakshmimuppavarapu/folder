package com.cg.plp.service;

import java.util.ArrayList;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.BookRegistrationBean;
import com.cg.plp.dao.ILMSDao;
import com.cg.plp.dao.LMSDaoImpl;
import com.cg.plp.exception.LibraryException;
import com.cg.plp.exception.StudentException;

public class StudentServiceImpl implements IStudentService
{
	ILMSDao lmsDao=new LMSDaoImpl(); 
	
	@Override
	public ArrayList<BookBean> showBooks() throws LibraryException
	{
		return lmsDao.showBooks();
	}

	@Override
	public int isBookAvailable(String bookId) throws StudentException
	{
		return lmsDao.isBookAvailable(bookId);
	}

	@Override
	public String addRequest(String userId, String bookId) throws StudentException
	{
		return lmsDao.addRequest(userId,bookId);
	}

	@Override
	public ArrayList<BookRegistrationBean> showUserBooks(String userid) throws StudentException 
	{
		return lmsDao.showUserBooks(userid);
	}

	@Override
	public int returnBook(String transactionId, String bookId) throws StudentException
	{
		return lmsDao.returnBook( transactionId,bookId);
	}

}
