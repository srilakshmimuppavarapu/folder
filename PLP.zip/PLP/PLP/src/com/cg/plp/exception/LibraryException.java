package com.cg.plp.exception;

public class LibraryException extends Exception
{
	private String msg;
	
	public LibraryException(String msg)
	{
		super(msg);
	}
	public String toString()
	{
		return this.msg;
	}
}
