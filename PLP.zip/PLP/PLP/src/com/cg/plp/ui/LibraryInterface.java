package com.cg.plp.ui;

import java.util.Scanner;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.StudentBean;
import com.cg.plp.exception.LibraryException;
import com.cg.plp.service.LibraryServiceImpl;

public class LibraryInterface 
{	
	public static void main(String[] args) 
	{
		String id=null;
		String pwd=null;
		int choice=0;
		int choose=0;
		
		StudentBean studentbean=new StudentBean();
		BookBean bookBean=new BookBean();
		LibraryServiceImpl libraryServiceImpl=new LibraryServiceImpl();
		
		Scanner scan=new Scanner(System.in);
		
		System.out.println("1. Registration");
		System.out.println("2. Login");
		System.out.println("Enter the choice");
		
		choose=scan.nextInt();
		
		if(choose==1)
		{
			System.out.println("Enter the name");
			String name=scan.next();
			System.out.println("Enter the emailid");
			String email=scan.next();
			System.out.println("Enter the password");
			String pass=scan.next();
			System.out.println("Enter your address");
			String address=scan.next();
			System.out.println("Enter the phone number");
			String phoneNo=scan.next();
			System.out.println("Enter the gender");
			String gender=scan.next();
			System.out.println("Are you a librarian(Y/N)");
			String lib=scan.next();
			
			studentbean.setsName(name);
			studentbean.setsEmailId(email);
			studentbean.setsPassword(pass);
			studentbean.setsAddress(address);
			studentbean.setsPhonenum(phoneNo);
			studentbean.setsGender(gender);
			studentbean.setLibrarian(lib);
			
			boolean status=libraryServiceImpl.registerUser(studentbean);
			
			if(status)
			{
				System.out.println("Registered successfully..");
			}
			else
				System.out.println("Registration failed...");
		}
		else if(choose==2)
		{
			System.out.println("Enter your choice:\n1)Student\n2)Librarian");
			choice=scan.nextInt();
			switch(choice)
			{
				case 1:
					try
					{
						do
						{
							System.out.println("UserId: ");
							id=scan.next();
							System.out.println("Password: ");
							pwd=scan.next();
						}while(libraryServiceImpl.isStudentValid(id,pwd));
						studentbean.setsUserId(id);
						studentbean.setsPassword(pwd);
						System.out.println("Enter a book id:");
						bookBean.setBookId(scan.next());			
					}
					catch(LibraryException e)
					{
						System.out.println(e.getMessage());
					}
			
			}
		}
		else
		{
			System.out.println("Please enter the valid choice");
		}
	}
}
