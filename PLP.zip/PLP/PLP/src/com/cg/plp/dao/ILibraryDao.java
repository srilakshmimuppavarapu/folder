package com.cg.plp.dao;

import com.cg.plp.bean.StudentBean;
import com.cg.plp.exception.LibraryException;

public interface ILibraryDao 
{
	public abstract boolean isStudentValid(String id,String pwd);
	public abstract boolean registerUser(StudentBean studentBean);
}
