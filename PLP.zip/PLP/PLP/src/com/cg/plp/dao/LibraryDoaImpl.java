package com.cg.plp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.plp.bean.StudentBean;
import com.cg.plp.exception.LibraryException;
import com.cg.plp.util.LibraryDBConnection;


public class LibraryDoaImpl implements ILibraryDao
{
	@Override
	public boolean isStudentValid(String id,String pwd)
	{
		boolean status=false;
		
		
		
		try
		{
			Connection connection = LibraryDBConnection.getConnection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
			preparedStatement = connection.prepareStatement("SELECT password FROM UserTable WHERE userid=?");
			preparedStatement.setString(1, id);
			resultSet=preparedStatement.executeQuery();
			
			//resultSet.next();
			
			if(resultSet.next())
			{
				String pass=resultSet.getString("password");
				if(pass.equals(pwd))
				{
					status=false;
				}
				else
				{
					System.out.println("Incorrect password.Please enter a valid password");
					status=true;
				}
			}
			else
			{
				System.out.println("Incorrect userid.Please enter a valid userid");
				status=true;
			}
			return status;
		}
		catch(Exception e)
		{
//			throw new LibraryException("db problem");
		}
		return status;

//		finally
//		{
//			try 
//			{
//				resultSet.close();
//				preparedStatement.close();
//				connection.close();
//			}
//			catch (SQLException sqlException) 
//			{
//				throw new LibraryException("Error in closing db connection");
//			}
//		}
	}

	@Override
	public boolean registerUser(StudentBean studentBean)
	{
		
		boolean status=true;
		
		try
		{
			Connection connection = LibraryDBConnection.getConnection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
			preparedStatement = connection.prepareStatement(IQueryMapper.INSERTDETAILS);
			preparedStatement.setString(2,studentBean.getsPassword());
			preparedStatement.setString(2,studentBean.getsName());
			preparedStatement.setString(2,studentBean.getsEmailId());
			preparedStatement.setString(2,studentBean.getsAddress());
			preparedStatement.setString(2,studentBean.getsGender());
			preparedStatement.setString(2,studentBean.getsPhonenum());
			preparedStatement.setString(2,studentBean.getLibrarian());
			System.out.println("Hai");
			preparedStatement.executeUpdate();
		
			return status;
		}
		catch(Exception e)
		{
//			//throw new LibraryException("Caught "+sqlException.getMessage());
//			System.out.println("SQL Exception");
//			return false;
//			throw new LibraryException("db problem123");
		}
		return status;

//		finally
//		{
//			try 
//			{
//				resultSet.close();
//				preparedStatement.close();
//				connection.close();
//			}
//			catch (SQLException sqlException) 
//			{
//				throw new LibraryException("Error in closing db connection");
//			}
//		}
	}
}
