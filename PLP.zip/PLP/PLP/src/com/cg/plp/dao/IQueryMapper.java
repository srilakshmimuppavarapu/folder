package com.cg.plp.dao;

public interface IQueryMapper 
{
	public static final String INSERTDETAILS="INSERT INTO UserTable VALUES (user_seq_id,?,?,?,?,?,?,?)";
}
