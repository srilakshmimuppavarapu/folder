package com.cg.plp.bean;

public class StudentBean 
{
	private String sUserId=null;
	private String sPassword=null;
	private String sName=null;
	private String sEmailId=null;
	private String sAddress=null;
	private String sGender=null;
	private String sPhonenum=null;
	private String librarian=null;
	
	public String getsUserId() 
	{
		return sUserId;
	}
	public void setsUserId(String sUserId)
	{
		this.sUserId = sUserId;
	}
	
	public String getsPassword() 
	{
		return sPassword;
	}
	public void setsPassword(String sPassword)
	{
		this.sPassword = sPassword;
	}
	
	public String getsName() 
	{
		return sName;
	}
	public void setsName(String sName)
	{
		this.sName = sName;
	}
	
	public String getsEmailId() 
	{
		return sEmailId;
	}
	public void setsEmailId(String sEmailId)
	{
		this.sEmailId = sEmailId;
	}
	
	public String getsAddress() 
	{
		return sAddress;
	}
	public void setsAddress(String sAddress)
	{
		this.sAddress = sAddress;
	}
	
	public String getsGender() 
	{
		return sGender;
	}
	public void setsGender(String sGender)
	{
		this.sGender = sGender;
	}
	
	public String getsPhonenum() 
	{
		return sPhonenum;
	}
	public void setsPhonenum(String sPhonenum) 
	{
		this.sPhonenum = sPhonenum;
	}
	
	public String getLibrarian() 
	{
		return librarian;
	}
	public void setLibrarian(String librarian) 
	{
		this.librarian = librarian;
	}
}
