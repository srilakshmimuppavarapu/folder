package com.cg.plp.service;

import com.cg.plp.bean.StudentBean;
import com.cg.plp.dao.*;
import com.cg.plp.exception.LibraryException;

public class LibraryServiceImpl implements ILibraryService
{
	ILibraryDao libraryDaoImpl=new LibraryDoaImpl();
	
	
	public boolean isStudentValid(String id,String pwd)
	{
		return libraryDaoImpl.isStudentValid(id,pwd);
	}
	
	@Override
	public boolean registerUser(StudentBean studentBean)
	{
		return libraryDaoImpl.registerUser(studentBean);
	}
}
