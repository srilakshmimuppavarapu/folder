package com.cg.plp.service;

import com.cg.plp.bean.StudentBean;
import com.cg.plp.exception.LibraryException;

public interface ILibraryService 
{
	public abstract boolean isStudentValid(String id,String pwd);
	public abstract boolean registerUser(StudentBean studentBean);
}
