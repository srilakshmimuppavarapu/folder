package com.cg.plp.service;

import com.cg.plp.exception.LibraryException;

public interface ILibraryService 
{
	public abstract boolean isStudentValid(String id,String pwd) throws LibraryException;
}
