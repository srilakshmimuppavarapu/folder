package com.cg.plp.service;

import com.cg.plp.dao.*;
import com.cg.plp.exception.LibraryException;

public class LibraryServiceImpl implements ILibraryService
{
	ILibraryDao libraryDaoImpl=new LibraryDoaImpl();
	public boolean isStudentValid(String id,String pwd) throws LibraryException
	{
		return libraryDaoImpl.isStudentValid(id,pwd);
	}
}
