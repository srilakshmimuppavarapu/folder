package com.cg.plp.ui;

import java.util.Scanner;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.StudentBean;
import com.cg.plp.exception.LibraryException;
import com.cg.plp.service.LibraryServiceImpl;

public class LibraryInterface 
{	
	public static void main(String[] args)
	{
		String id=null;
		String pwd=null;
		int choice=0;
		
		StudentBean studentbean=new StudentBean();
		BookBean bookBean=new BookBean();
		LibraryServiceImpl libraryServiceImpl=new LibraryServiceImpl();
		
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Enter your choice:\n1)Student\n2)Librarian");
		choice=scan.nextInt();
		switch(choice)
		{
			case 1:
				try
				{
					do
					{
						System.out.println("UserId: ");
						id=scan.next();
						System.out.println("Password: ");
						pwd=scan.next();
					}while(libraryServiceImpl.isStudentValid(id,pwd));
					studentbean.setsUserId(id);
					studentbean.setsPassword(pwd);
					System.out.println("Enter a book id:");
					bookBean.setBookId(scan.next());
					if(isBookAvailable())
					{
						
					}
					else
					{
						
					}
				}
				catch(LibraryException e)
				{
					System.out.println(e.getMessage());
				}
		
		}
	}
}
