package com.cg.plp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.plp.exception.LibraryException;
import com.cg.plp.util.LibraryDBConnection;


public class LibraryDoaImpl implements ILibraryDao
{
	public boolean isStudentValid(String id,String pwd) throws LibraryException
	{
		boolean status=false;
		
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		try
		{
			preparedStatement = connection.prepareStatement("SELECT password FROM UserTable WHERE userid=?");
			preparedStatement.setString(1, id);
			resultSet=preparedStatement.executeQuery();
			//System.out.println("Entered uid:"+id);
			//System.out.println("Entered pwd:"+pwd);
			if(resultSet.next())
			{
				String pass=resultSet.getString("password");
				if(pass.equals(pwd))
				{
					//System.out.println("entered1");
					status=false;
				}
				else
				{
					System.out.println("Incorrect password.Please enter a valid password");
					status=true;
				}
			}
			else
			{
				System.out.println("Incorrect userid.Please enter a valid userid");
				status=true;
			}
			return status;
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing db connection");
			}
		}
	}
}
