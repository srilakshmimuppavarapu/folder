package com.cg.plp.dao;

import com.cg.plp.exception.LibraryException;

public interface ILibraryDao 
{
	public abstract boolean isStudentValid(String id,String pwd) throws LibraryException;
}
