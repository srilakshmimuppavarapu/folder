package com.cg.ebill.exception;

public class EBillException extends Exception
{
	private String msg;

	public EBillException(String msg)
	{
			this.msg=msg;
	}
	public String toString()
	{
		return this.msg;
	}
	
}
